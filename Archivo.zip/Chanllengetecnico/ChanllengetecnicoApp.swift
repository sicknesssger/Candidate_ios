//
//  ChanllengetecnicoApp.swift
//  Chanllengetecnico
//
//  Created by Gerardo Enrique Mendez Raigoso on 4/08/24.
//

import SwiftUI

@main
struct ChanllengetecnicoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
